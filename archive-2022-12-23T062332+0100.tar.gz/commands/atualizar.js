module.exports = {
    name: 'atualizar',
    aliases: ['up'],
    code: `
Comandos atualizados!
$updateCommands
$onlyForIDs[$botOwnerID;]
`
    }
   